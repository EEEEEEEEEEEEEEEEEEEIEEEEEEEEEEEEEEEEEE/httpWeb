//
//  ResultInfo.swift
//  Xcode
//
//  Created by Hanxun on 2017/9/23.
//  Copyright © 2017年 Simon. All rights reserved.
//

import UIKit

class ResultInfo: NSObject {
    
    // Result Code (0:Success, 9999:Error)
    var ResultId: Int?
    var Message: Int?
}
