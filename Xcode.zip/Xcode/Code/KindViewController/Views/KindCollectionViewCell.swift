//
//  KindCollectionViewCell.swift
//  Xcode
//
//  Created by Hanxun on 2017/9/18.
//  Copyright © 2017年 Simon. All rights reserved.
//

import UIKit

class KindCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var workerIdLabel: UILabel!
    @IBOutlet weak var coinTypeLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
